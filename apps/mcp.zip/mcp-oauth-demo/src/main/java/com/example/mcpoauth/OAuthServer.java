package com.example.mcpoauth;

import com.example.mcpoauth.oauth.AuthSession;
import com.example.mcpoauth.oauth.AuthorizationServerMetadataServlet;
import com.example.mcpoauth.oauth.AuthorizeServlet;
import com.example.mcpoauth.oauth.ConsentServlet;
import com.example.mcpoauth.oauth.LoginServlet;
import com.example.mcpoauth.oauth.McpAuthFilter;
import com.example.mcpoauth.oauth.OAuthProvider;
import com.example.mcpoauth.oauth.OAuthTokenService;
import com.example.mcpoauth.oauth.ProtectedResourceMetadataServlet;
import com.example.mcpoauth.oauth.RegisterServlet;
import com.example.mcpoauth.oauth.TokenServlet;
import com.example.mcpoauth.tools.DemoTools;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.modelcontextprotocol.server.McpServer;
import io.modelcontextprotocol.server.McpSyncServer;
import io.modelcontextprotocol.server.transport.HttpServletSseServerTransportProvider;
import io.modelcontextprotocol.server.transport.HttpServletStreamableServerTransportProvider;
import io.modelcontextprotocol.spec.McpSchema;
import jakarta.servlet.DispatcherType;
import org.eclipse.jetty.ee11.servlet.FilterHolder;
import org.eclipse.jetty.ee11.servlet.ServletContextHandler;
import org.eclipse.jetty.ee11.servlet.ServletHolder;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.ServerConnector;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;

/** Embedded Jetty server exposing OAuth endpoints + the protected MCP endpoint. */
public final class OAuthServer {
    private final Server jetty;
    private final OAuthProvider provider;
    private final List<McpSyncServer> mcpServers = new ArrayList<>();

    public OAuthServer(String host, int port) throws Exception {
        this(host, port, "demo", "MCP OAuth demo", "#2e5bff");
    }

    public OAuthServer(String host, int port, String platformId, String displayName, String brandColor) throws Exception {
        String baseUrl = "http://" + host + ":" + port;
        provider = new OAuthProvider(baseUrl, platformId, displayName, brandColor);
        OAuthTokenService tokenService = new OAuthTokenService(Util.randomToken() + "-" + Util.randomToken());
        AuthSession sessions = new AuthSession(tokenService);

        jetty = new Server();
        ServerConnector connector = new ServerConnector(jetty);
        connector.setHost(host);
        connector.setPort(port);
        jetty.addConnector(connector);

        ServletContextHandler ctx = new ServletContextHandler(ServletContextHandler.SESSIONS);
        ctx.setContextPath("/");

        ctx.addServlet(new ServletHolder(new ProtectedResourceMetadataServlet(provider)), OAuthProvider.PRM_PATH);
        ctx.addServlet(new ServletHolder(new AuthorizationServerMetadataServlet(provider)), "/.well-known/oauth-authorization-server");
        ctx.addServlet(new ServletHolder(new RegisterServlet(provider)), "/register");
        ctx.addServlet(new ServletHolder(new AuthorizeServlet()), "/authorize");
        ctx.addServlet(new ServletHolder(new ConsentServlet(provider, sessions)), "/consent");
        ctx.addServlet(new ServletHolder(new LoginServlet(provider, sessions)), "/login");
        ctx.addServlet(new ServletHolder(new TokenServlet(provider)), "/token");

        addMcpRoute(ctx, "/mcp", null, false);
        addMcpRoute(ctx, "/mcp/workbuddy", "workbuddy", false);
        addMcpRoute(ctx, "/mcp/trae", "trae", true);
        addTraeSseRoute(ctx, "/mcp/trae/sse");
        addMcpRoute(ctx, "/mcp/cursor", "cursor", false);

        jetty.setHandler(ctx);
    }

    private void addMcpRoute(ServletContextHandler ctx, String path, String platform, boolean allowAnonymous) {
        HttpServletStreamableServerTransportProvider transport = DemoMcpServer.transport(path);
        McpSyncServer mcpServer = DemoMcpServer.create(transport);
        mcpServers.add(mcpServer);
        ctx.addServlet(new ServletHolder(transport), path);
        ctx.addFilter(new FilterHolder(new McpAuthFilter(provider, platform, allowAnonymous)), path, EnumSet.of(DispatcherType.REQUEST));
    }

    private void addTraeSseRoute(ServletContextHandler ctx, String path) {
        // Trae (and several older MCP clients) speak the original HTTP+SSE transport,
        // not the newer Streamable HTTP + OAuth discovery. Mount a classic SSE endpoint
        // on the same URL (GET for the event stream, POST for JSON-RPC messages).
        HttpServletSseServerTransportProvider transport = HttpServletSseServerTransportProvider.builder()
                .objectMapper(new ObjectMapper())
                .baseUrl(provider.serverBaseUrl())
                .sseEndpoint(path)
                .messageEndpoint(path)
                .build();

        McpSyncServer mcpServer = McpServer.sync(transport)
                .serverInfo("mcp-oauth-demo", "1.0.0")
                .capabilities(McpSchema.ServerCapabilities.builder().tools(true).build())
                .instructions("Demo MCP server (Trae classic SSE). No OAuth required for local demo.")
                .tool(DemoTools.tool(), DemoTools::handle)
                .build();
        mcpServers.add(mcpServer);

        ctx.addServlet(new ServletHolder(transport), path);
        ctx.addFilter(new FilterHolder(new McpAuthFilter(provider, "trae", true)), path, EnumSet.of(DispatcherType.REQUEST));
    }

    public OAuthProvider provider() { return provider; }

    public void start() throws Exception { jetty.start(); }
    public void join() throws InterruptedException { jetty.join(); }
    public void stop() throws Exception {
        for (McpSyncServer srv : mcpServers) {
            srv.closeGracefully();
        }
        jetty.stop();
    }
}