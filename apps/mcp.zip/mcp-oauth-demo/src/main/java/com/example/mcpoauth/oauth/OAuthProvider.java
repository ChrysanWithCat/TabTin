package com.example.mcpoauth.oauth;

import com.example.mcpoauth.Util;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

/** Tiny in-memory OAuth 2.0 authorization server state used by the demo. */
public final class OAuthProvider {

    public static final String MCP_SCOPE = "mcp";
    /** Static demo token used by clients that do not support OAuth (for example Trae). */
    public static final String STATIC_DEMO_TOKEN = "trae-demo-token";
    public static final String PRM_PATH = "/.well-known/oauth-protected-resource";

    public record Client(String clientId, String clientSecret, List<String> redirectUriPatterns, List<String> scopes,
                         String displayName, String brandColor) {
        public boolean matchesRedirectUri(String redirectUri) {
            if (redirectUri == null) return false;
            return redirectUriPatterns.stream().anyMatch(p -> {
                try { return Pattern.compile(p).matcher(redirectUri).matches(); }
                catch (Exception e) { return false; }
            });
        }
    }

    public record AuthCode(String value, String clientId, String redirectUri,
                           String codeChallenge, String codeChallengeMethod,
                           String username, List<String> scopes, Instant expiresAt, boolean used) {
        public boolean isUsed() { return used; }
        public AuthCode markUsed() { return new AuthCode(value, clientId, redirectUri, codeChallenge, codeChallengeMethod, username, scopes, expiresAt, true); }
    }

    public record AccessToken(String value, String clientId, String username,
                              List<String> scopes, Instant expiresAt) {
        public boolean isExpired() { return Instant.now().isAfter(expiresAt); }
    }

    private final String serverBaseUrl;
    private final String platformId;
    private final String displayName;
    private final String brandColor;
    private final Map<String, Client> clients = new ConcurrentHashMap<>();
    private final Map<String, AuthCode> codes = new ConcurrentHashMap<>();
    private final Map<String, AccessToken> tokens = new ConcurrentHashMap<>();
    private final Map<String, String> users = new ConcurrentHashMap<>();

    public OAuthProvider(String serverBaseUrl) {
        this(serverBaseUrl, "demo", "MCP OAuth 演示", "#2e5bff");
    }

    public OAuthProvider(String serverBaseUrl, String platformId, String displayName, String brandColor) {
        this.serverBaseUrl = serverBaseUrl;
        this.platformId = platformId;
        this.displayName = displayName;
        this.brandColor = brandColor;
        users.put("demo", "demo123");
        users.put("admin", "admin123");
        registerClient("mcp-demo-client", "demo-secret", List.of("http://127.0.0.1:\\d{1,5}/callback", "http://localhost:\\d{1,5}/callback"));
        registerClient("workbuddy-client", "demo-secret", List.of("http://127.0.0.1:\\d{1,5}/callback", "http://localhost:\\d{1,5}/callback"),
                "WorkBuddy 授权", "#4f46e5");
        registerClient("trae-client", "demo-secret", List.of("http://127.0.0.1:\\d{1,5}/callback", "http://localhost:\\d{1,5}/callback"),
                "Trae 授权", "#00a550");
        registerClient("cursor-client", "demo-secret", List.of("http://127.0.0.1:\\d{1,5}/callback", "http://localhost:\\d{1,5}/callback"),
                "Cursor 授权", "#7c3aed");
    }

    public String serverBaseUrl() { return serverBaseUrl; }
    public String platformId() { return platformId; }
    public String displayName() { return displayName; }
    public String brandColor() { return brandColor; }

    public void registerClient(String clientId, String clientSecret, List<String> redirectUriPatterns) {
        registerClient(clientId, clientSecret, redirectUriPatterns, "MCP OAuth 演示", "#2e5bff");
    }

    public void registerClient(String clientId, String clientSecret, List<String> redirectUriPatterns,
                               String displayName, String brandColor) {
        clients.put(clientId, new Client(clientId, clientSecret, new ArrayList<>(redirectUriPatterns), List.of(MCP_SCOPE), displayName, brandColor));
    }

    public Client getClient(String clientId) { return clients.get(clientId); }

    public Client getPlatformClient(String platform) {
        if (platform == null || platform.isBlank()) return null;
        return switch (platform) {
            case "workbuddy" -> clients.get("workbuddy-client");
            case "trae" -> clients.get("trae-client");
            case "cursor" -> clients.get("cursor-client");
            default -> null;
        };
    }

    public boolean checkUser(String username, String password) {
        return users.containsKey(username) && users.get(username).equals(password);
    }

    public Client registerDynamicClient(String name, String redirectUri) {
        String clientId = Util.randomId("client");
        String secret = Util.randomToken();
        clients.put(clientId, new Client(clientId, secret, List.of(Pattern.quote(redirectUri)), List.of(MCP_SCOPE), name, "#2e5bff"));
        return clients.get(clientId);
    }

    public AuthCode createAuthCode(String clientId, String redirectUri, String codeChallenge,
                                   String codeChallengeMethod, String username, List<String> scopes) {
        AuthCode code = new AuthCode(Util.randomCode(), clientId, redirectUri, codeChallenge,
                codeChallengeMethod == null ? "S256" : codeChallengeMethod, username,
                scopes == null || scopes.isEmpty() ? List.of(MCP_SCOPE) : scopes,
                Instant.now().plus(Duration.ofMinutes(10)), false);
        codes.put(code.value(), code);
        return code;
    }

    public AuthCode takeAuthCode(String code) {
        return codes.remove(code);
    }

    public AccessToken createAccessToken(String clientId, String username, List<String> scopes) {
        AccessToken token = new AccessToken(Util.randomToken(), clientId, username,
                scopes == null || scopes.isEmpty() ? List.of(MCP_SCOPE) : scopes,
                Instant.now().plus(Duration.ofHours(1)));
        tokens.put(token.value(), token);
        return token;
    }

    public AccessToken validateAccessToken(String tokenValue) {
        AccessToken t = tokens.get(tokenValue);
        if (t == null || t.isExpired()) {
            tokens.remove(tokenValue);
            return null;
        }
        return t;
    }

    public boolean verifyPkce(AuthCode code, String codeVerifier) {
        try {
            if (codeVerifier == null || codeVerifier.isEmpty()) return false;
            if ("S256".equalsIgnoreCase(code.codeChallengeMethod())) {
                return Util.sha256B64u(codeVerifier).equals(code.codeChallenge());
            }
            return codeVerifier.equals(code.codeChallenge());
        } catch (Exception e) {
            return false;
        }
    }

    public void purgeExpired() {
        long now = System.currentTimeMillis();
        codes.values().removeIf(c -> c.expiresAt().toEpochMilli() < now);
        tokens.values().removeIf(t -> t.expiresAt().toEpochMilli() < now);
    }
}