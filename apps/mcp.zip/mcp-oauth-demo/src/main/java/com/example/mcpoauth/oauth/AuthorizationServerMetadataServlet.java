package com.example.mcpoauth.oauth;

import com.example.mcpoauth.Json;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

/** Serves the OAuth 2.0 Authorization Server Metadata document (RFC 8414), optionally platform-scoped. */
public class AuthorizationServerMetadataServlet extends HttpServlet {
    private final OAuthProvider provider;
    private final ObjectMapper mapper = new ObjectMapper();

    public AuthorizationServerMetadataServlet(OAuthProvider provider) {
        this.provider = provider;
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String platform = normalizePlatform(req.getParameter("platform"));
        String base = provider.serverBaseUrl();
        String authorize = base + "/authorize" + (platform == null ? "" : "?platform=" + platform);
        resp.setStatus(200);
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        resp.setHeader("Cache-Control", "no-store");
        mapper.writeValue(resp.getWriter(), Json.map(
                "issuer", base,
                "authorization_endpoint", authorize,
                "token_endpoint", base + "/token",
                "registration_endpoint", base + "/register",
                "response_types_supported", List.of("code"),
                "grant_types_supported", List.of("authorization_code"),
                "token_endpoint_auth_methods_supported", List.of("client_secret_basic", "client_secret_post", "none"),
                "scopes_supported", List.of(OAuthProvider.MCP_SCOPE),
                "code_challenge_methods_supported", List.of("S256")
        ));
    }

    private String normalizePlatform(String platform) {
        if (platform == null || platform.isBlank()) return null;
        String p = platform.trim().toLowerCase();
        if ("workbuddy".equals(p) || "trae".equals(p) || "cursor".equals(p)) return p;
        return null;
    }
}