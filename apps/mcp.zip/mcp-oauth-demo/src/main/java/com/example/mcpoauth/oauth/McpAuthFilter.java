package com.example.mcpoauth.oauth;

import com.example.mcpoauth.Json;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/** Guards MCP endpoints: without a valid access token it returns 401 + WWW-Authenticate: resource_metadata. */
public class McpAuthFilter implements Filter {
    private final OAuthProvider provider;
    private final String platform;
    private final boolean allowAnonymous;
    private final ObjectMapper mapper = new ObjectMapper();

    public McpAuthFilter(OAuthProvider provider) {
        this(provider, null, false);
    }

    public McpAuthFilter(OAuthProvider provider, String platform) {
        this(provider, platform, "trae".equals(platform));
    }

    public McpAuthFilter(OAuthProvider provider, String platform, boolean allowAnonymous) {
        this.provider = provider;
        this.platform = platform;
        this.allowAnonymous = allowAnonymous;
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;

        // Trae does not support OAuth (and many versions cannot send custom headers),
        // so the dedicated /mcp/trae demo path is intentionally unauthenticated.
        if (allowAnonymous) {
            chain.doFilter(req, resp);
            return;
        }

        String auth = req.getHeader("Authorization");
        String token = null;
        if (auth != null && auth.regionMatches(true, 0, "Bearer ", 0, 7)) {
            token = auth.substring(7).trim();
        }
        if (token != null && !token.isEmpty() && OAuthProvider.STATIC_DEMO_TOKEN.equals(token)) {
            chain.doFilter(req, resp);
            return;
        }

        OAuthProvider.AccessToken accessToken = token == null || token.isEmpty() ? null : provider.validateAccessToken(token);
        if (accessToken == null) {
            String prm = provider.serverBaseUrl() + OAuthProvider.PRM_PATH;
            if (platform != null && !platform.isBlank()) {
                prm += "?platform=" + platform;
            }
            resp.setStatus(401);
            resp.setHeader("WWW-Authenticate",
                    "Bearer resource_metadata=\"" + prm + "\"");
            resp.setContentType("application/json");
            resp.setCharacterEncoding("UTF-8");
            mapper.writeValue(resp.getWriter(), Json.map(
                    "error", "invalid_or_missing_access_token",
                    "error_description", "Visit " + prm + " to discover the authorization flow"
            ));
            return;
        }

        chain.doFilter(req, resp);
    }
}