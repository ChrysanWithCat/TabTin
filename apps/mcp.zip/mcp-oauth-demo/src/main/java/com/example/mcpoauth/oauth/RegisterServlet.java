package com.example.mcpoauth.oauth;

import com.example.mcpoauth.Json;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

/** Dynamic client registration endpoint (RFC 7591) so MCP clients can self-register. */
public class RegisterServlet extends HttpServlet {
    private final OAuthProvider provider;
    private final ObjectMapper mapper = new ObjectMapper();

    public RegisterServlet(OAuthProvider provider) {
        this.provider = provider;
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        JsonNode body = mapper.readTree(req.getInputStream());
        String redirectUri = body.path("redirect_uris").isArray()
                ? body.path("redirect_uris").get(0).asText()
                : body.path("redirect_uri").asText();
        String clientName = body.path("client_name").asText("mcp-demo-client");

        if (redirectUri == null || redirectUri.isBlank()) {
            sendError(resp, 400, "invalid_client_metadata", "redirect_uris is required");
            return;
        }

        OAuthProvider.Client client = provider.registerDynamicClient(clientName, redirectUri);
        resp.setStatus(201);
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        mapper.writeValue(resp.getWriter(), Json.map(
                "client_id", client.clientId(),
                "client_secret", client.clientSecret(),
                "client_id_issued_at", System.currentTimeMillis() / 1000,
                "client_secret_expires_at", 0,
                "redirect_uris", List.of(redirectUri),
                "token_endpoint_auth_method", "client_secret_post",
                "grant_types", List.of("authorization_code"),
                "response_types", List.of("code"),
                "scope", String.join(" ", client.scopes())
        ));
    }

    private void sendError(HttpServletResponse resp, int status, String code, String desc) throws IOException {
        resp.setStatus(status);
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        mapper.writeValue(resp.getWriter(), Json.map("error", code, "error_description", desc));
    }
}
