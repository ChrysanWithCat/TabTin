package com.example.mcpoauth;

import com.example.mcpoauth.oauth.OAuthProvider;

/** Entry point for the demo MCP OAuth server. */
public final class Main {
    public static void main(String[] args) throws Exception {
        String host = "127.0.0.1";
        int port = 8080;
        String platformId = "demo";
        for (int i = 0; i < args.length; i++) {
            switch (args[i]) {
                case "--host" -> host = args[++i];
                case "--port" -> port = Integer.parseInt(args[++i]);
                case "--platform" -> platformId = args[++i];
                case "--help", "-h" -> {
                    System.out.println("""
                        Usage: mcp-oauth-demo.jar [--host 127.0.0.1] [--port 8080] [--platform demo|workbuddy|trae|cursor]
                        Supported platforms: demo, workbuddy, trae, cursor
                        MCP endpoint:      http://<host>:<port>/mcp
                        Platform paths:    /mcp/workbuddy  /mcp/trae  /mcp/cursor
                        Trae legacy SSE:   /mcp/trae/sse   (type: sse)
                        OAuth PRM:         http://<host>:<port>/.well-known/oauth-protected-resource
                        OAuth authorize:   http://<host>:<port>/authorize
                        OAuth token:       http://<host>:<port>/token
                        Dynamic register:  POST http://<host>:<port>/register
                        Demo login:        demo / demo123   (admin / admin123)
                        Pre-registered client: mcp-demo-client / demo-secret
                        """);
                    return;
                }
                default -> { /* ignore */ }
            }
        }

        String displayName = switch (platformId) {
            case "workbuddy" -> "WorkBuddy 授权";
            case "trae" -> "Trae 授权";
            case "cursor" -> "Cursor 授权";
            default -> "MCP OAuth 演示";
        };
        String brandColor = switch (platformId) {
            case "workbuddy" -> "#4f46e5";
            case "trae" -> "#00a550";
            case "cursor" -> "#7c3aed";
            default -> "#2e5bff";
        };
        OAuthServer server = new OAuthServer(host, port, platformId, displayName, brandColor);
        server.start();
        System.out.println("MCP OAuth demo server started");
        System.out.println("  MCP endpoint:       http://" + host + ":" + port + "/mcp");
        System.out.println("  Platform paths:     /mcp/workbuddy  /mcp/trae  /mcp/cursor");
        System.out.println("  Trae legacy SSE:    /mcp/trae/sse   (type: sse)");
        System.out.println("  PRM discovery:      http://" + host + ":" + port + OAuthProvider.PRM_PATH);
        System.out.println("  Authorize:          http://" + host + ":" + port + "/authorize");
        System.out.println("  Token:              http://" + host + ":" + port + "/token");
        System.out.println("  Dynamic register:   POST http://" + host + ":" + port + "/register");
        System.out.println("  Platform:           " + platformId + " (" + displayName + ")");
        System.out.println("  Demo user:          demo / demo123");
        System.out.println("  Pre-registered OAuth client: mcp-demo-client / demo-secret (loopback callback)");
        System.out.println("Press Ctrl+C to stop.");
        server.join();
    }
}