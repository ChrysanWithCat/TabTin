package com.example.mcpoauth.oauth;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/** Serves the OAuth 2.0 Protected Resource Metadata (RFC 9728) document, optionally platform-scoped. */
public class ProtectedResourceMetadataServlet extends HttpServlet {
    private final OAuthProvider provider;

    public ProtectedResourceMetadataServlet(OAuthProvider provider) {
        this.provider = provider;
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String platform = normalizePlatform(req.getParameter("platform"));
        String base = provider.serverBaseUrl();
        String mcpPath = platform == null ? "/mcp" : "/mcp/" + platform;
        String prmUrl = base + OAuthProvider.PRM_PATH + (platform == null ? "" : "?platform=" + platform);
        String asUrl = base + "/.well-known/oauth-authorization-server" + (platform == null ? "" : "?platform=" + platform);
        String json = """
        {
          "resource": "%s%s",
          "resource_metadata": "%s",
          "authorization_servers": ["%s"],
          "scopes_supported": ["%s"],
          "bearer_methods_supported": ["header"],
          "resource_metadata_uri_parameter": "resource_metadata",
          "token_endpoint_auth_methods_supported": ["client_secret_basic", "client_secret_post", "none"],
          "pkce_supported": ["S256"]
        }
        """.formatted(base, mcpPath, prmUrl, asUrl, OAuthProvider.MCP_SCOPE);
        resp.setStatus(200);
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        resp.getWriter().write(json);
    }

    private String normalizePlatform(String platform) {
        if (platform == null || platform.isBlank()) return null;
        String p = platform.trim().toLowerCase();
        if ("workbuddy".equals(p) || "trae".equals(p) || "cursor".equals(p)) return p;
        return null;
    }
}