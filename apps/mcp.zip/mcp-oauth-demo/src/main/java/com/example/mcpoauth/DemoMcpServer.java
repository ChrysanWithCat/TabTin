package com.example.mcpoauth;

import com.example.mcpoauth.tools.DemoTools;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.modelcontextprotocol.server.McpServer;
import io.modelcontextprotocol.server.McpSyncServer;
import io.modelcontextprotocol.server.transport.HttpServletStreamableServerTransportProvider;
import io.modelcontextprotocol.spec.McpSchema;

/** Builds the official-SDK MCP server over the Streamable HTTP transport. */
public final class DemoMcpServer {
    private DemoMcpServer() {}

    public static HttpServletStreamableServerTransportProvider transport() {
        return transport("/mcp");
    }

    public static HttpServletStreamableServerTransportProvider transport(String mcpEndpoint) {
        return HttpServletStreamableServerTransportProvider.builder()
                .objectMapper(new ObjectMapper())
                .mcpEndpoint(mcpEndpoint)
                .build();
    }

    public static McpSyncServer create(HttpServletStreamableServerTransportProvider transport) {
        return McpServer.sync(transport)
                .serverInfo("mcp-oauth-demo", "1.0.0")
                .capabilities(McpSchema.ServerCapabilities.builder().tools(true).build())
                .instructions("Demo MCP server protected by OAuth 2.0 Authorization Code + PKCE.")
                .tool(DemoTools.tool(), DemoTools::handle)
                .build();
    }
}