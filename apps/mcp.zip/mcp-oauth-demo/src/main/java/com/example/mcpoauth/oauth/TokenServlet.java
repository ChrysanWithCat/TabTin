package com.example.mcpoauth.oauth;

import com.example.mcpoauth.Json;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

/** /token: exchanges an Authorization Code (+ PKCE verifier) for an Access Token. */
public class TokenServlet extends HttpServlet {
    private final OAuthProvider provider;
    private final ObjectMapper mapper = new ObjectMapper();

    public TokenServlet(OAuthProvider provider) {
        this.provider = provider;
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String grantType = req.getParameter("grant_type");
        if (!"authorization_code".equals(grantType)) {
            sendError(resp, 400, "unsupported_grant_type", "only authorization_code is supported");
            return;
        }

        String code = req.getParameter("code");
        String redirectUri = req.getParameter("redirect_uri");
        String verifier = req.getParameter("code_verifier");

        OAuthProvider.AuthCode authCode = provider.takeAuthCode(code == null ? "" : code);

        ClientCredentials clientCreds = extractClientCredentials(req);
        OAuthProvider.Client client;
        if (clientCreds.clientId() != null && !clientCreds.clientId().isBlank()) {
            client = provider.getClient(clientCreds.clientId());
            if (client == null) {
                sendError(resp, 401, "invalid_client", "unknown client_id");
                return;
            }
            if (client.clientSecret() != null && !client.clientSecret().isBlank()
                    && !client.clientSecret().equals(clientCreds.clientSecret())) {
                sendError(resp, 401, "invalid_client", "client_secret mismatch");
                return;
            }
        } else if (authCode != null) {
            // Some MCP clients cannot/do not forward client_id in the token request.
            // For this local demo we still derive the client from the authorization code.
            client = provider.getClient(authCode.clientId());
            if (client == null) {
                sendError(resp, 401, "invalid_client", "unknown client_id");
                return;
            }
        } else {
            sendError(resp, 400, "invalid_client", "client_id is required");
            return;
        }

        if (authCode == null || authCode.isUsed()) {
            sendError(resp, 400, "invalid_grant", "authorization code not found or already used");
            return;
        }
        if (!authCode.clientId().equals(client.clientId())) {
            sendError(resp, 400, "invalid_grant", "code was issued to a different client");
            return;
        }
        if (redirectUri != null && !redirectUri.equals(authCode.redirectUri())) {
            sendError(resp, 400, "invalid_grant", "redirect_uri mismatch");
            return;
        }
        if (!provider.verifyPkce(authCode, verifier)) {
            sendError(resp, 400, "invalid_grant", "PKCE verification failed");
            return;
        }

        OAuthProvider.AccessToken token = provider.createAccessToken(client.clientId(), authCode.username(), authCode.scopes());
        resp.setStatus(200);
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        resp.setHeader("Cache-Control", "no-store");
        resp.setHeader("Pragma", "no-cache");
        mapper.writeValue(resp.getWriter(), Json.map(
                "access_token", token.value(),
                "token_type", "Bearer",
                "expires_in", 3600,
                "scope", String.join(" ", token.scopes())
        ));
    }

    private ClientCredentials extractClientCredentials(HttpServletRequest req) {
        String auth = req.getHeader("Authorization");
        if (auth != null && auth.regionMatches(true, 0, "Basic ", 0, 6)) {
            try {
                String decoded = new String(Base64.getDecoder().decode(auth.substring(6).trim()), StandardCharsets.UTF_8);
                int i = decoded.indexOf(':');
                if (i > 0) return new ClientCredentials(decoded.substring(0, i), decoded.substring(i + 1));
            } catch (Exception ignored) { }
        }
        String id = req.getParameter("client_id");
        String secret = req.getParameter("client_secret");
        return new ClientCredentials(id == null || id.isBlank() ? null : id, secret);
    }

    private void sendError(HttpServletResponse resp, int status, String code, String desc) throws IOException {
        resp.setStatus(status);
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        resp.setHeader("Cache-Control", "no-store");
        mapper.writeValue(resp.getWriter(), Json.map("error", code, "error_description", desc));
    }

    private record ClientCredentials(String clientId, String clientSecret) {}
}