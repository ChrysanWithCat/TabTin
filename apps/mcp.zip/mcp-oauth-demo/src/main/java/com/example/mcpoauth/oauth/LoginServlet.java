package com.example.mcpoauth.oauth;

import com.example.mcpoauth.Util;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;

/** Login page + POST handler. After login it redirects back to the saved target URL (the /authorize request). */
public class LoginServlet extends HttpServlet {
    private final OAuthProvider provider;
    private final AuthSession sessions;

    public LoginServlet(OAuthProvider provider, AuthSession sessions) {
        this.provider = provider;
        this.sessions = sessions;
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String target = req.getParameter("target");
        if (target == null || target.isBlank()) target = "/consent";
        resp.setContentType("text/html; charset=UTF-8");
        resp.getWriter().write(page(target, null, clientFromTarget(target)));
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, jakarta.servlet.ServletException {
        String target = req.getParameter("target");
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String error = null;

        if (!provider.checkUser(username == null ? "" : username.trim(), password == null ? "" : password)) {
            error = "用户名或密码错误，演示账号：demo / demo123，admin / admin123";
            resp.setContentType("text/html; charset=UTF-8");
            resp.getWriter().write(page(target == null ? "/consent" : target, error, clientFromTarget(target)));
            return;
        }

        try {
            String cookieValue = sessions.createCookie(username.trim()).split("=", 2)[1];
            resp.addHeader("Set-Cookie", sessions.cookieHeader(cookieValue, 600));
        } catch (Exception e) {
            throw new jakarta.servlet.ServletException(e);
        }
        resp.sendRedirect(target == null ? "/consent" : target);
    }

    private String page(String target, String error, OAuthProvider.Client client) {
        String displayName = client == null ? provider.displayName() : client.displayName();
        String brandColor = client == null ? provider.brandColor() : client.brandColor();
        String err = error == null ? "" : "<p style='color:#b42318'>" + Util.htmlEscape(error) + "</p>";
        String css = "body{font-family:system-ui;background:#f4f6fb;display:flex;align-items:center;justify-content:center;height:100vh;margin:0}" +
                ".card{background:#fff;border-radius:16px;padding:32px 40px;width:360px;box-shadow:0 20px 60px rgba(0,0,0,.12)}" +
                "h1{font-size:22px;margin:0 0 4px}.sub{color:#667085;margin:0 0 24px;font-size:14px}" +
                "label{display:block;font-size:14px;font-weight:600;margin:12px 0 6px}" +
                "input[type=text],input[type=password]{width:100%;box-sizing:border-box;padding:10px 12px;border:1px solid #d0d5dd;border-radius:8px;font-size:14px}" +
                "button{margin-top:20px;width:100%;padding:11px;background:" + brandColor + ";color:#fff;border:0;border-radius:8px;font-size:15px;font-weight:600;cursor:pointer}" +
                "button:hover{background:#1e4ae0}" +
                ".hint{margin-top:16px;font-size:12px;color:#98a2b3;line-height:1.5}";
        return "<!DOCTYPE html><html lang=\"zh-CN\"><head><meta charset=\"UTF-8\"><title>MCP OAuth 登录</title><style>" + css + "</style></head><body>" +
                "<form class=\"card\" method=\"post\" action=\"/login\">" +
                "<h1>" + displayName + "</h1><p class=\"sub\">演示环境，登录后完成授权并自动携带 Token 访问 MCP</p>" + err +
                "<input type=\"hidden\" name=\"target\" value=\"" + Util.htmlEscape(target) + "\">" +
                "<label>用户名</label><input type=\"text\" name=\"username\" autocomplete=\"username\" required>" +
                "<label>密码</label><input type=\"password\" name=\"password\" autocomplete=\"current-password\" required>" +
                "<button type=\"submit\">登录并授权</button>" +
                "<div class=\"hint\">演示账号：demo / demo123<br>admin / admin123</div></form></body></html>";
    }

    private OAuthProvider.Client clientFromTarget(String target) {
        if (target == null || target.isBlank()) return null;
        try {
            String decoded = URLDecoder.decode(target, StandardCharsets.UTF_8);
            int q = decoded.indexOf('?');
            if (q < 0) return null;
            String clientId = null;
            String platform = null;
            for (String pair : decoded.substring(q + 1).split("&")) {
                if (pair.startsWith("client_id=")) {
                    clientId = URLDecoder.decode(pair.substring(10), StandardCharsets.UTF_8);
                } else if (pair.startsWith("platform=")) {
                    platform = URLDecoder.decode(pair.substring(9), StandardCharsets.UTF_8);
                }
            }
            if (clientId != null && !clientId.isBlank()) {
                OAuthProvider.Client c = provider.getClient(clientId);
                if (c != null) return c;
            }
            if (platform != null && !platform.isBlank()) {
                OAuthProvider.Client c = provider.getPlatformClient(platform);
                if (c != null) return c;
            }
        } catch (Exception ignored) {
            // ignore
        }
        return null;
    }
}