package com.example.mcpoauth.oauth;

import com.example.mcpoauth.Util;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/**
 * /consent: shows what the client asks for and lets the demo user approve (or cancel).
 * On approval it issues an Authorization Code and redirects back to the client's redirect_uri.
 */
public class ConsentServlet extends HttpServlet {
    private final OAuthProvider provider;
    private final AuthSession sessions;

    public ConsentServlet(OAuthProvider provider, AuthSession sessions) {
        this.provider = provider;
        this.sessions = sessions;
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String username = sessions.readCookie(req.getCookies());
        if (username == null) {
            String target = req.getRequestURL().toString() + (req.getQueryString() == null ? "" : "?" + req.getQueryString());
            resp.sendRedirect("/login?target=" + URLEncoder.encode(target, StandardCharsets.UTF_8));
            return;
        }

        String clientId = req.getParameter("client_id");
        String redirectUri = req.getParameter("redirect_uri");
        String state = req.getParameter("state");
        String codeChallenge = req.getParameter("code_challenge");
        String codeChallengeMethod = req.getParameter("code_challenge_method");
        String scope = req.getParameter("scope");
        String platform = req.getParameter("platform");

        OAuthProvider.Client client = clientId == null || clientId.isBlank() ? null : provider.getClient(clientId.trim());
        if (client == null && platform != null && !platform.isBlank()) {
            client = provider.getPlatformClient(platform);
            if (client != null) clientId = client.clientId();
        }
        if (client == null || !client.matchesRedirectUri(redirectUri)) {
            renderError(resp, "客户端参数无效（client_id 或 redirect_uri 不匹配）");
            return;
        }

        String action = req.getParameter("action");
        if ("approve".equals(action)) {
            if (codeChallenge == null || codeChallenge.isBlank()) {
                renderError(resp, "缺少 code_challenge（PKCE S256 是必选的）");
                return;
            }
            String[] scopes = scope == null || scope.isBlank() ? new String[]{OAuthProvider.MCP_SCOPE} : scope.split("\\s+");
            OAuthProvider.AuthCode code = provider.createAuthCode(clientId, redirectUri,
                    codeChallenge, codeChallengeMethod, username, java.util.List.of(scopes));
            String sep = redirectUri.contains("?") ? "&" : "?";
            resp.sendRedirect(redirectUri + sep + "code=" + URLEncoder.encode(code.value(), StandardCharsets.UTF_8)
                    + (state == null ? "" : "&state=" + URLEncoder.encode(state, StandardCharsets.UTF_8)));
            return;
        }
        if ("deny".equals(action)) {
            String sep = redirectUri.contains("?") ? "&" : "?";
            resp.sendRedirect(redirectUri + sep + "error=access_denied"
                    + (state == null ? "" : "&state=" + URLEncoder.encode(state, StandardCharsets.UTF_8)));
            return;
        }

        resp.setContentType("text/html; charset=UTF-8");
        String html = "<!DOCTYPE html><html lang=\"zh-CN\"><head><meta charset=\"UTF-8\"><title>授权确认</title><style>" +
                "body{font-family:system-ui;background:#f4f6fb;display:flex;align-items:center;justify-content:center;height:100vh;margin:0}" +
                ".card{background:#fff;border-radius:16px;padding:32px 40px;width:440px;box-shadow:0 20px 60px rgba(0,0,0,.12)}" +
                "h1{font-size:22px;margin:0 0 6px}.sub{color:#667085;font-size:14px;margin:0 0 20px}" +
                ".row{display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid #eef2f7;font-size:14px}" +
                ".row b{color:#101828}.scope{background:#eef4ff;color:#1d4ed8;border-radius:20px;padding:3px 10px;font-size:13px}" +
                ".buttons{display:flex;gap:12px;margin-top:24px}button{flex:1;padding:11px;border-radius:8px;font-size:15px;font-weight:600;cursor:pointer}" +
                ".approve{background:" + client.brandColor() + ";color:#fff;border:0}.approve:hover{background:#1e4ae0}" +
                ".deny{background:#fff;color:#344054;border:1px solid #d0d5dd}</style></head><body>" +
                "<form class=\"card\" method=\"get\" action=\"/consent\">" +
                "<h1>" + client.displayName() + " · 请求授权</h1><p class=\"sub\">客户端希望访问你的 MCP 资源</p>" +
                "<div class=\"row\"><span>客户端</span><b>" + Util.htmlEscape(clientId) + "</b></div>" +
                "<div class=\"row\"><span>登录用户</span><b>" + Util.htmlEscape(username) + "</b></div>" +
                "<div class=\"row\"><span>请求的 Scope</span><span class=\"scope\">" + Util.htmlEscape(scope == null ? OAuthProvider.MCP_SCOPE : scope) + "</span></div>" +
                "<div class=\"row\"><span>回调地址</span><b style=\"max-width:200px;word-break:break-all\">" + Util.htmlEscape(redirectUri) + "</b></div>" +
                "<input type=\"hidden\" name=\"client_id\" value=\"" + Util.htmlEscape(clientId) + "\">" +
                "<input type=\"hidden\" name=\"redirect_uri\" value=\"" + Util.htmlEscape(redirectUri) + "\">" +
                "<input type=\"hidden\" name=\"state\" value=\"" + Util.htmlEscape(state == null ? "" : state) + "\">" +
                "<input type=\"hidden\" name=\"code_challenge\" value=\"" + Util.htmlEscape(codeChallenge == null ? "" : codeChallenge) + "\">" +
                "<input type=\"hidden\" name=\"code_challenge_method\" value=\"" + Util.htmlEscape(codeChallengeMethod == null ? "S256" : codeChallengeMethod) + "\">" +
                "<input type=\"hidden\" name=\"scope\" value=\"" + Util.htmlEscape(scope == null ? OAuthProvider.MCP_SCOPE : scope) + "\">" +
                "<div class=\"buttons\"><button type=\"submit\" name=\"action\" value=\"approve\" class=\"approve\">同意并继续</button>" +
                "<button type=\"submit\" name=\"action\" value=\"deny\" class=\"deny\">取消</button></div></form></body></html>";
        resp.getWriter().write(html);
    }

    private void renderError(HttpServletResponse resp, String msg) throws IOException {
        resp.setContentType("text/html; charset=UTF-8");
        resp.setStatus(400);
        resp.getWriter().write("<html><head><meta charset='UTF-8'></head><body><h3>" + Util.htmlEscape(msg) + "</h3></body></html>");
    }
}