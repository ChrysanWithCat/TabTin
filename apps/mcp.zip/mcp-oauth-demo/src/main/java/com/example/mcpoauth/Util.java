package com.example.mcpoauth;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.UUID;

/** Small crypto + URL helpers shared by the demo server. */
public final class Util {
    private Util() {}

    private static final Base64.Encoder B64U = Base64.getUrlEncoder().withoutPadding();
    private static final Base64.Decoder B64UD = Base64.getUrlDecoder();
    private static final SecureRandom RANDOM = new SecureRandom();

    public static String randomToken() {
        byte[] b = new byte[32];
        RANDOM.nextBytes(b);
        return B64U.encodeToString(b);
    }

    public static String randomCode() {
        return randomToken().substring(0, 24);
    }

    public static String randomId(String prefix) {
        return prefix + "-" + UUID.randomUUID().toString().substring(0, 8);
    }

    public static String b64uEncode(byte[] bytes) {
        return B64U.encodeToString(bytes);
    }

    public static byte[] b64uDecode(String s) {
        return B64UD.decode(s);
    }

    public static String sha256B64u(String value) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        return B64U.encodeToString(md.digest(value.getBytes(java.nio.charset.StandardCharsets.US_ASCII)));
    }

    public static String hmacSha256B64u(String secret, String data) throws Exception {
        javax.crypto.Mac mac = javax.crypto.Mac.getInstance("HmacSHA256");
        mac.init(new javax.crypto.spec.SecretKeySpec(secret.getBytes(java.nio.charset.StandardCharsets.UTF_8), "HmacSHA256"));
        return B64U.encodeToString(mac.doFinal(data.getBytes(java.nio.charset.StandardCharsets.UTF_8)));
    }

    public static String htmlEscape(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&#39;");
    }
}
