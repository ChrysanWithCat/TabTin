package com.example.mcpoauth.oauth;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/** /authorize entrypoint: delegates to /consent (which handles login redirect + approval). */
public class AuthorizeServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String q = req.getQueryString();
        String target = "/consent" + (q == null || q.isBlank() ? "" : "?" + q);
        resp.sendRedirect(target);
    }
}
