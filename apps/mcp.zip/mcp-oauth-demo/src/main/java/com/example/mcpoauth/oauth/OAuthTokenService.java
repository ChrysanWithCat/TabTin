package com.example.mcpoauth.oauth;

import com.example.mcpoauth.Util;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.nio.charset.StandardCharsets;
import java.time.Instant;

/**
 * Stateless signed value helper: used for login session cookies and for a simple
 * signed JSON web token used as the access token in this demo.
 *
 * Format: base64url(headerJson).base64url(payloadJson).base64url(HMAC-SHA256)
 */
public final class OAuthTokenService {
    private final String secret;
    private final ObjectMapper mapper = new ObjectMapper();

    public OAuthTokenService(String secret) { this.secret = secret; }

    public String sign(String payloadJson) throws Exception {
        String header = Util.b64uEncode("{\"alg\":\"HS256\",\"typ\":\"JWT\"}".getBytes(StandardCharsets.UTF_8));
        String payload = Util.b64uEncode(payloadJson.getBytes(StandardCharsets.UTF_8));
        String data = header + "." + payload;
        return data + "." + Util.hmacSha256B64u(secret, data);
    }

    public String signPayload(String subject, String scope, long ttlSeconds) throws Exception {
        ObjectNode node = mapper.createObjectNode();
        node.put("sub", subject);
        node.put("scope", scope);
        node.put("iat", Instant.now().getEpochSecond());
        node.put("exp", Instant.now().plusSeconds(ttlSeconds).getEpochSecond());
        return sign(mapper.writeValueAsString(node));
    }

    public boolean verify(String value) {
        try {
            String[] parts = value.split("\\.");
            if (parts.length != 3) return false;
            String expected = Util.hmacSha256B64u(secret, parts[0] + "." + parts[1]);
            if (!slowEquals(expected, parts[2])) return false;
            JsonNode payload = mapper.readTree(Util.b64uDecode(parts[1]));
            long exp = payload.path("exp").asLong(0);
            return exp > Instant.now().getEpochSecond();
        } catch (Exception e) {
            return false;
        }
    }

    public String subject(String value) {
        try {
            String[] parts = value.split("\\.");
            JsonNode payload = mapper.readTree(Util.b64uDecode(parts[1]));
            return payload.path("sub").asText();
        } catch (Exception e) {
            return null;
        }
    }

    private static boolean slowEquals(String a, String b) {
        byte[] x = a.getBytes(StandardCharsets.UTF_8);
        byte[] y = b.getBytes(StandardCharsets.UTF_8);
        int diff = x.length ^ y.length;
        for (int i = 0; i < x.length && i < y.length; i++) diff |= x[i] ^ y[i];
        return diff == 0;
    }
}
