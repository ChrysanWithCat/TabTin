package com.example.mcpoauth.tools;

import io.modelcontextprotocol.server.McpSyncServerExchange;
import io.modelcontextprotocol.spec.McpSchema;

import java.util.Map;

/** A sample MCP tool exposed by the protected server. */
public final class DemoTools {
    private DemoTools() {}

    public static McpSchema.Tool tool() {
        String inputSchema = """
        {
          "type": "object",
          "properties": {
            "text": {"type": "string", "description": "Text to echo"}
          },
          "required": ["text"]
        }
        """;
        return McpSchema.Tool.builder()
                .name("echo")
                .description("Echoes the provided text back to the caller. This tool is only reachable with a valid OAuth access token.")
                .inputSchema(inputSchema)
                .build();
    }

    public static McpSchema.CallToolResult handle(McpSyncServerExchange exchange, Map<String, Object> args) {
        String text = String.valueOf(args == null ? "hello" : args.getOrDefault("text", "hello"));
        return McpSchema.CallToolResult.builder()
                .addTextContent("Echo (authenticated): " + text)
                .build();
    }
}