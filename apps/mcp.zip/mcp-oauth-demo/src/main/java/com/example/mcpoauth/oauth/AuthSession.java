package com.example.mcpoauth.oauth;

import com.example.mcpoauth.Util;

/** Handles the signed login-session cookie used by the demo browser flow. */
public final class AuthSession {
    private final OAuthTokenService tokens;
    private final String cookieName = "mcp_demo_session";

    public AuthSession(OAuthTokenService tokens) {
        this.tokens = tokens;
    }

    public String cookieName() { return cookieName; }

    public String createCookie(String username) throws Exception {
        return cookieName + "=" + tokens.signPayload(username, "session", 600);
    }

    public String readCookie(jakarta.servlet.http.Cookie[] cookies) {
        if (cookies == null) return null;
        for (jakarta.servlet.http.Cookie c : cookies) {
            if (cookieName.equals(c.getName()) && tokens.verify(c.getValue())) {
                return tokens.subject(c.getValue());
            }
        }
        return null;
    }

    public String cookieHeader(String cookieValue, int maxAgeSeconds) {
        return cookieName + "=" + cookieValue + "; Path=/; HttpOnly; SameSite=Lax; Max-Age=" + maxAgeSeconds;
    }
}
