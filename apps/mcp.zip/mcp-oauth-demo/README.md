# MCP OAuth Demo（Java）

一个用 Java / Jetty / MCP Java SDK 实现的 **Streamable HTTP MCP Server** 示例：
- MCP 端点受 OAuth 2.0 **Authorization Code + PKCE (S256)** 保护。
- 实现 **Protected Resource Metadata（PRM，RFC 9728）** 发现机制。
- 配置支持 OAuth 的 MCP 客户端时，客户端会先收到 `401`，跟随 `WWW-Authenticate` 找到 PRM，自动拉起浏览器跳转到授权登录页；用户登录并同意后，客户端会自动用授权码换取 Access Token，并在后续 MCP 请求中携带 `Authorization: Bearer <token>`。

## 功能

| 功能 | 说明 |
| --- | --- |
| MCP 端点 | `GET/POST /mcp`（Streamable HTTP） |
| PRM 发现 | `GET /.well-known/oauth-protected-resource` |
| OAuth 服务器元数据 | `GET /.well-known/oauth-authorization-server`（RFC 8414） |
| 授权端点 | `GET /authorize` → `/consent` → `/login` |
| 令牌端点 | `POST /token`（Authorization Code + PKCE） |
| 动态客户端注册 | `POST /register`（RFC 7591 简化实现） |
| 受保护资源校验 | `McpAuthFilter` 校验 Bearer Token |
| 示例 MCP 工具 | `echo(text)` |

## 技术栈

- Java 21
- Maven
- [MCP Java SDK](https://github.com/modelcontextprotocol/java-sdk) `io.modelcontextprotocol.sdk:mcp:0.12.0`
- Jetty 12 (`jetty-ee11-servlet`)
- Jackson

## 构建

```powershell
cd E:\1-AIWorkspace\mcp\mcp-oauth-demo
mvn -DskipTests package
```

生成可执行 jar：

```text
target\mcp-oauth-demo.jar
```

## 运行

```powershell
java -jar target\mcp-oauth-demo.jar --host 127.0.0.1 --port 8080
```

默认 `--host 127.0.0.1 --port 8080`；可用 `--help` 查看参数。

启动后输出类似：

```text
MCP endpoint:       http://127.0.0.1:8080/mcp
PRM discovery:      http://127.0.0.1:8080/.well-known/oauth-protected-resource
Authorize:          http://127.0.0.1:8080/authorize
Token:              http://127.0.0.1:8080/token
Dynamic register:   POST http://127.0.0.1:8080/register
```

## 演示账号

| 用户名 | 密码 |
| --- | --- |
| `demo` | `demo123` |
| `admin` | `admin123` |

## MCP 客户端配置

### 预注册客户端（推荐用于本地调试）

服务端已预注册一个 OAuth 客户端：

```text
client_id:     mcp-demo-client
client_secret: demo-secret
redirect_uri:  http://127.0.0.1:<port>/callback
              http://localhost:<port>/callback
```

如果你使用的 MCP 客户端支持自定义 client 配置，可以填：

```json
{
  "mcpServers": {
    "mcp-oauth-demo": {
      "url": "http://127.0.0.1:8080/mcp/workbuddy",
      "type": "http"
    }
  }
}
```

> 注意：
> - 上面的配置是最小可运行配置，`type` 字段名取决于你所使用的 MCP 客户端；关键是把 MCP URL 指向 `http://127.0.0.1:8080/mcp`，且服务端已经启动。
> - **不要**把 `clientId` / `clientSecret` / `scopes` 直接塞进所有客户端的配置里。只有你的客户端明确支持自定义 OAuth 客户端参数时，才需要额外配置这些字段；不支持的客户端看到未知字段可能直接报错。
> - 本 Demo 服务端预注册的 OAuth 客户端 `mcp-demo-client` 仅用于浏览器授权时的 client 身份；对大多数支持 MCP OAuth 的客户端，直接给 `url` 即可，客户端会自动做 PRM 发现 → 动态注册或使用默认 client → 浏览器授权。

项目根目录还提供了 `mcp-servers.example.json` 作为可参考的配置模板。

#### WorkBuddy 配置（支持 OAuth，推荐）

如果你使用 WorkBuddy，并且已确认它能处理 MCP OAuth 流程，直接用最小配置即可：

```json
{
  "mcpServers": {
    "mcp-oauth-demo": {
      "url": "http://127.0.0.1:8080/mcp/workbuddy",
      "type": "http"
    }
  }
}
```

WorkBuddy 会自动处理：

```text
请求 /mcp/workbuddy
  → 401 + WWW-Authenticate resource_metadata?platform=workbuddy
  → GET /.well-known/oauth-protected-resource（PRM）
  → GET /.well-known/oauth-authorization-server（AS 元数据）
  → 打开浏览器授权页
  → 登录 demo / demo123
  → 换 Token
  → 后续 MCP 调用自动带 Authorization: Bearer <token>
```

### Trae 不支持 OAuth 时的替代方式

Trae 不支持 OAuth（也不能像 WorkBuddy 那样自动做 PRM/OAuth 发现），所以额外提供两条**本地 Demo 免授权路径**：
- `/mcp/trae/sse`：经典 HTTP+SSE（老式 MCP transport），Trae 这类客户端通常用 `type: sse`；
- `/mcp/trae`：Streamable HTTP（新式 transport），Trae 若只认 `type: http` 可用这条。
- 两条路径都不需要 `client_id`、不需要 OAuth 跳转、不需要配置 `Authorization`（即使配置了静态 Token 也会放行）。

#### 方案 A：Trae 经典 HTTP+SSE（推荐先试）

```json
{
  "mcpServers": {
    "mcp-oauth-demo-trae": {
      "url": "http://127.0.0.1:8080/mcp/trae/sse",
      "type": "sse"
    }
  }
}
```

#### 方案 B：Trae 用 Streamable HTTP（如果 Trae 版本只认 `type: http`）

```json
{
  "mcpServers": {
    "mcp-oauth-demo-trae-http": {
      "url": "http://127.0.0.1:8080/mcp/trae",
      "type": "http"
    }
  }
}
```

如果你用的 Trae 支持自定义请求头，也可以给 Streamable HTTP 方案额外带上静态 Token（可选）：

```json
{
  "mcpServers": {
    "mcp-oauth-demo-trae-http": {
      "url": "http://127.0.0.1:8080/mcp/trae",
      "type": "http",
      "headers": {
        "Authorization": "Bearer trae-demo-token"
      }
    }
  }
}
```

> `/mcp/trae` 与 `/mcp/trae/sse` 免授权只适合本地 Demo，不适合生产。
## 动态客户端注册（适合支持 RFC 7591 的客户端）

客户端可通过 PRM / 授权服务器发现后，向 `/register` 注册自己的 `redirect_uri`：

```http
POST /register HTTP/1.1
Host: 127.0.0.1:8080
Content-Type: application/json

{
  "client_name": "my-mcp-client",
  "redirect_uris": ["http://127.0.0.1:63342/callback"]
}
```

返回：

```json
{
  "client_id": "client-...",
  "client_secret": "...",
  "scope": "mcp",
  "redirect_uris": ["http://127.0.0.1:63342/callback"]
}
```

之后客户端以该 `client_id` / `client_secret` 发起授权码 + PKCE 流程。

### 支持的 OAuth 流程（授权码 + PKCE）

1. MCP 客户端首次访问 `/mcp`，服务端返回 `401`，并在 `WWW-Authenticate` 中返回 `resource_metadata` 指向 PRM。
2. 客户端读取 PRM，找到 `authorization_servers` 与 `scopes_supported`。
3. 客户端生成 PKCE `code_verifier` / `code_challenge`，将用户浏览器导向 `/authorize?client_id=...&redirect_uri=...&scope=mcp&code_challenge=...`.
4. 用户未登录则跳转 `/login`；登录成功后回到 `/consent` 授权确认页。
5. 用户点击“同意并继续”，服务端把授权码通过 `redirect_uri` 回调给客户端。
6. 客户端用 `/token` 交换 Access Token（校验 `code_verifier`）。
7. 后续 MCP 请求携带 `Authorization: Bearer <token>`。

## 直接 HTTP 验证（不依赖客户端）

### 1. 获取 PRM

```powershell
Invoke-RestMethod http://127.0.0.1:8080/.well-known/oauth-protected-resource
```

### 2. 获取 OAuth 服务器元数据（MCP 客户端会自动读取这里）

```powershell
Invoke-RestMethod http://127.0.0.1:8080/.well-known/oauth-authorization-server
```

返回 `authorization_endpoint`、`token_endpoint`、`registration_endpoint` 等。

### 3. 未带 Token 访问 `/mcp`

```powershell
try {
  Invoke-WebRequest http://127.0.0.1:8080/mcp -Method GET | Out-Null
} catch {
  $_.Exception.Response.StatusCode.value__
  $_.Exception.Response.Headers['WWW-Authenticate']
}
```

预期返回 `401`，`WWW-Authenticate` 类似：

```text
Bearer resource_metadata="http://127.0.0.1:8080/.well-known/oauth-protected-resource"
```

### 4. 浏览器手动授权

也可直接在浏览器打开：

```text
http://127.0.0.1:8080/authorize?client_id=mcp-demo-client&redirect_uri=http%3A%2F%2F127.0.0.1%3A8080%2Fcallback&scope=mcp&response_type=code&code_challenge=YOUR_CHALLENGE&code_challenge_method=S256&state=xyz
```

> 这里 `code_challenge` 必须是你自己保存的 `code_verifier` 的 S256 摘要；演示登录账号见上文。浏览器最终会跳转到你指定的 `redirect_uri` 并带上 `code`。

### 5. 令牌交换

```powershell
$params = @{
  grant_type    = 'authorization_code'
  code          = '<上一步拿到的 code>'
  redirect_uri  = 'http://127.0.0.1:<你的端口>/callback'
  code_verifier = '<你保存的 code_verifier>'
  client_id     = 'mcp-demo-client'
  client_secret = 'demo-secret'
}
Invoke-RestMethod http://127.0.0.1:8080/token -Method Post -Body $params -ContentType 'application/x-www-form-urlencoded'
```

返回：

```json
{
  "access_token": "...",
  "token_type": "Bearer",
  "expires_in": 3600,
  "scope": "mcp"
}
```

### 6. 带 Token 调用 MCP

Streamable HTTP 需要同时带以下请求头：

- `Accept: application/json, text/event-stream`
- `Authorization: Bearer <token>`
- 初始化响应中的 `Mcp-Session-Id`（之后每次请求都要携带）

示例（PowerShell）：

```powershell
$headers = @{
  'Accept'          = 'application/json, text/event-stream'
  'Authorization'   = "Bearer $accessToken"
  'Content-Type'    = 'application/json'
}
$body = @{
  jsonrpc = '2.0'
  id = 1
  method = 'initialize'
  params = @{
    protocolVersion = '2025-03-26'
    capabilities = @{}
    clientInfo = @{ name = 'demo'; version = '1.0' }
  }
} | ConvertTo-Json -Depth 8
$init = Invoke-WebRequest http://127.0.0.1:8080/mcp -Method Post -Headers $headers -Body $body
$sessionId = [string]$init.Headers['Mcp-Session-Id']
$init.Content
```

之后在 `$headers` 中加入 `'Mcp-Session-Id' = $sessionId`，继续调用：

```powershell
$headers['Mcp-Session-Id'] = $sessionId
$body = @{ jsonrpc='2.0'; id=2; method='tools/list'; params=@{} } | ConvertTo-Json -Depth 5
Invoke-WebRequest http://127.0.0.1:8080/mcp -Method Post -Headers $headers -Body $body
```

调用 `echo` 工具：

```powershell
$body = @{
  jsonrpc = '2.0'
  id = 3
  method = 'tools/call'
  params = @{ name = 'echo'; arguments = @{ text = 'hello-oAuth' } }
} | ConvertTo-Json -Depth 8
Invoke-WebRequest http://127.0.0.1:8080/mcp -Method Post -Headers $headers -Body $body
```

预期 SSE 事件里包含：

```json
"Echo (authenticated): hello-oAuth"
```

## 目录结构

```text
mcp-oauth-demo/
├─ pom.xml
├─ src/main/java/com/example/mcpoauth/
│  ├─ Main.java
│  ├─ OAuthServer.java
│  ├─ DemoMcpServer.java
│  ├─ Json.java
│  ├─ Util.java
│  ├─ oauth/
│  │  ├─ OAuthProvider.java
│  │  ├─ ProtectedResourceMetadataServlet.java
│  │  ├─ RegisterServlet.java
│  │  ├─ AuthorizeServlet.java
│  │  ├─ ConsentServlet.java
│  │  ├─ LoginServlet.java
│  │  ├─ TokenServlet.java
│  │  ├─ AuthSession.java
│  │  ├─ OAuthTokenService.java
│  │  └─ McpAuthFilter.java
│  └─ tools/
│     └─ DemoTools.java
├─ scripts/
│  └─ oauth-demo.ps1
├─ mcp-servers.example.json
├─ README.md
├─ .gitignore
└─ target/mcp-oauth-demo.jar
```

## 一键演示脚本

项目内附带了 `scripts\oauth-demo.ps1`，会自动完成完整的 OAuth 授权码 + PKCE + MCP 调用流程：

```powershell
powershell -ExecutionPolicy Bypass -File scripts\oauth-demo.ps1 -BaseUrl http://127.0.0.1:8087
```

脚本参数：

| 参数 | 默认值 |
| --- | --- |
| `-BaseUrl` | `http://127.0.0.1:8087` |
| `-Username` | `demo` |
| `-Password` | `demo123` |
| `-ClientId` | `mcp-demo-client` |
| `-ClientSecret` | `demo-secret` |


## 多平台：不同平台拷贝的 MCP 配置跳到各自的授权页

如果希望不同平台（WorkBuddy / Trae / Cursor / 其他）在配置同一个 Demo 时，跳转到各自的授权页面，推荐用「每个平台一个 MCP 地址」的方式。


### 同一服务、同一端口：用 /mcp/{platform} 路径（推荐，不依赖 client_id）

很多 MCP 客户端并不会把配置里的 `clientId` / `clientSecret` 透传给 `/authorize`，所以“不同 client_id 配置”并不总可靠。
为了让不同平台拷贝同一份服务却跳到不同的授权页，本 Demo 额外暴露了三个平台路径：

| 平台 | MCP 地址 |
| --- | --- |
| WorkBuddy | `http://127.0.0.1:8080/mcp/workbuddy` |
| Trae | `http://127.0.0.1:8080/mcp/trae/sse`（经典 SSE）或 `http://127.0.0.1:8080/mcp/trae`（Streamable HTTP） |
| Cursor | `http://127.0.0.1:8080/mcp/cursor` |

使用这些路径时，服务端返回的 PRM / AS 元数据会自动带上 `platform=xxx`：

- `GET /.well-known/oauth-protected-resource?platform=cursor`
- `GET /.well-known/oauth-authorization-server?platform=cursor`

这样**即使用户不在配置里写 `client_id`**，授权页也会显示对应平台的标题/品牌色，并默认使用对应的平台 OAuth 客户端（`workbuddy-client`、`trae-client`、`cursor-client`）。
### 启动不同平台实例

服务端支持 `--platform` 参数：

```powershell
# WorkBuddy 授权页（默认颜色/标题）
java -jar target\mcp-oauth-demo.jar --host 127.0.0.1 --port 8080 --platform workbuddy

# Trae 授权页
java -jar target\mcp-oauth-demo.jar --host 127.0.0.1 --port 8081 --platform trae

# Cursor 授权页
java -jar target\mcp-oauth-demo.jar --host 127.0.0.1 --port 8082 --platform cursor
```

### 各平台的 MCP 配置

平台配置里的 `url` 指向哪个路径，就会触发哪个平台的授权页。

WorkBuddy：

```json
{
  "mcpServers": {
    "mcp-oauth-demo-workbuddy": {
      "url": "http://127.0.0.1:8080/mcp/workbuddy",
      "type": "http"
    }
  }
}
```

Trae（Trae 不支持 OAuth，使用免授权路径，推荐 `/mcp/trae/sse` 经典 SSE）：

```json
{
  "mcpServers": {
    "mcp-oauth-demo-trae": {
      "url": "http://127.0.0.1:8080/mcp/trae/sse",
      "type": "sse"
    }
  }
}
```

如果 Trae 版本只认 `type: http` / Streamable HTTP，则用：

```json
{
  "mcpServers": {
    "mcp-oauth-demo-trae-http": {
      "url": "http://127.0.0.1:8080/mcp/trae",
      "type": "http"
    }
  }
}
```

Cursor（如果支持 OAuth，则走自动跳转）：

```json
{
  "mcpServers": {
    "mcp-oauth-demo-cursor": {
      "url": "http://127.0.0.1:8080/mcp/cursor",
      "type": "http"
    }
  }
}
```

### 扩展成生产方案

当前 Demo 用「不同端口」区分平台，方便本地验证。生产环境一般用：

1. **不同子域名**：如 `workbuddy.example.com`、`cursor.example.com`，每个域名启动对应平台实例，或由网关按域名路由。
2. **同一服务多租户**：本 Demo 已内置 `/mcp/workbuddy`、`/mcp/trae`、`/mcp/cursor` 路径路由；不需要依赖客户端传 `client_id`。生产环境可以换成不同的子域名或网关按路径/域名路由。
3. **配置中心 / 数据库**：把平台 ID、品牌色、授权页标题、OAuth client、允许回调地址都存起来，避免硬编码。
## 常见问题：fetch failed

如果客户端配置后报 `fetch failed`，优先检查以下几点：

1. **服务端是否真的在跑**：用浏览器或 PowerShell 打开 MCP 端点，确认能返回 OAuth `401`：
   ```powershell
   try {
     Invoke-WebRequest http://127.0.0.1:8080/mcp -Method GET -UseBasicParsing -ErrorAction Stop | Out-Null
   } catch {
     $_.Exception.Response.StatusCode.value__
     $_.Exception.Response.Headers['WWW-Authenticate']
   }
   ```
   正常应看到 `401` 和 `WWW-Authenticate`。如果提示“无法连接”，说明服务端没启动或端口不一致。

2. **端口是否一致**：`mcp-servers.example.json` 里写的是 `8080`；如果你用别的端口启动（例如 `--port 8087`），请同步改配置里的 `url`。

3. **不要堆不认识的字段**：很多 MCP 客户端只接受 `url` 等标准字段。把 `clientId` / `clientSecret` / `scopes` 写进配置，客户端可能会直接拒绝连接或无法处理。

4. **确认客户端支持远程 HTTP / OAuth MCP**：本 Demo 默认是 Streamable HTTP + OAuth。如果你的客户端不支持 MCP OAuth 发现，或只支持 stdio，它就无法完成“跳转授权后自动带 Token”的流程。

5. **Trae 等不支持 OAuth 的客户端，改用免授权 SSE 路径**：`/mcp/trae/sse`（经典 HTTP+SSE，配置 `"type": "sse"`）或 `/mcp/trae`（Streamable HTTP，配置 `"type": "http"`）。服务端对这两条路径不要求 Token，避免客户端把 401 / 400 报成 `fetch failed`。

6. **本地服务注意 HTTPS/回调**：生产 / 非 localhost 环境需要 HTTPS，并确保回调地址能被客户端访问。
## 常见问题：直接 Unauthorized，不跳转授权页

如果 MCP 客户端配置后直接显示 `401 Unauthorized`，但没有弹出浏览器授权页，通常是下面几种情况：

1. **客户端不支持 MCP OAuth 发现**：本 Demo 依赖客户端拿到 `401` 后读取 `WWW-Authenticate` 里的 `resource_metadata`，再去发现授权服务器并自动跳转。如果你的客户端不支持 MCP OAuth 流程，它只会把 `401` 原样返回给你。
   - 可先用支持的客户端验证，例如支持 Streamable HTTP + OAuth 的 MCP 客户端；或使用本仓库的 `scripts\oauth-demo.ps1` 验证服务端本身是好的。

2. **客户端没有读到授权服务器元数据**：现在服务端已提供 `/.well-known/oauth-authorization-server`，正常情况下客户端会通过 PRM 里的 `authorization_servers` 自动获取：
   - PRM：`http://127.0.0.1:8080/.well-known/oauth-protected-resource`
   - AS 元数据：`http://127.0.0.1:8080/.well-known/oauth-authorization-server`

3. **客户端要求预注册 client 或静态 OAuth 配置**：如果客户端不支持动态注册，可能需要在客户端配置里显式指定：
   ```json
   "oauth": {
     "client_id": "mcp-demo-client",
     "client_secret": "demo-secret",
     "authorization_url": "http://127.0.0.1:8080/authorize",
     "token_url": "http://127.0.0.1:8080/token"
   }
   ```
   但字段名要以你所用客户端为准，否则同样可能导致报错。
## 注意

- 这是 **Demo**：OAuth 客户端、授权码、Access Token、用户会话均存储在内存中，重启后失效。
- 未实现持久化，不支持多实例集群。
- PKCE 使用 S256，`/authorize` 要求传入 `code_challenge`，否则授权确认页会报错。
- 生产环境请使用 HTTPS、持久化存储、真实 Authorization Server，并自行实现 scope / audience 校验。
