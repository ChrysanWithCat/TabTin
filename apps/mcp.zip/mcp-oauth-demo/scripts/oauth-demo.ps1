<#
.SYNOPSIS
  Demonstrates the full OAuth 2.0 Authorization Code + PKCE flow for the MCP OAuth demo server.
  Compatible with Windows PowerShell 5.1+.

.EXAMPLE
  powershell -ExecutionPolicy Bypass -File scripts\oauth-demo.ps1 -BaseUrl http://127.0.0.1:8087
#>
[CmdletBinding()]
param(
    [string]$BaseUrl = 'http://127.0.0.1:8087',
    [string]$Username = 'demo',
    [string]$Password = 'demo123',
    [string]$ClientId = 'mcp-demo-client',
    [string]$ClientSecret = 'demo-secret'
)

$ErrorActionPreference = 'Stop'

if (-not $BaseUrl.EndsWith('/')) { $BaseUrl = $BaseUrl + '/' }
$mcpUrl   = $BaseUrl + 'mcp'
$prmUrl   = $BaseUrl + '.well-known/oauth-protected-resource'
$authUrl  = $BaseUrl + 'authorize'
$tokenUrl = $BaseUrl + 'token'
$loginUrl = $BaseUrl + 'login'
$redirectUri = $BaseUrl.TrimEnd('/') + '/callback'

function B64Url([byte[]]$bytes) {
    return [Convert]::ToBase64String($bytes).TrimEnd('=').Replace('+', '-').Replace('/', '_')
}

Write-Host "==> PRM discovery"
$prm = Invoke-RestMethod $prmUrl
Write-Host "    resource_metadata=$($prm.resource_metadata)"
Write-Host "    authorization_servers=$($prm.authorization_servers -join ', ')"

Write-Host "==> Generating PKCE (S256)"
$verifierBytes = New-Object byte[] 32
$rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
$rng.GetBytes($verifierBytes)
$rng.Dispose()
$codeVerifier = B64Url $verifierBytes
$sha = [System.Security.Cryptography.SHA256]::Create()
$codeChallenge = B64Url ($sha.ComputeHash([System.Text.Encoding]::ASCII.GetBytes($codeVerifier)))
Write-Host "    code_verifier=$codeVerifier"
Write-Host "    code_challenge=$codeChallenge"

$session = New-Object Microsoft.PowerShell.Commands.WebRequestSession
$state = 'demo-state'

Write-Host "==> Starting authorization request"
$authorizeQuery = "client_id=$([uri]::EscapeDataString($ClientId))&redirect_uri=$([uri]::EscapeDataString($redirectUri))&scope=mcp&response_type=code&state=$state&code_challenge=$codeChallenge&code_challenge_method=S256"
$loginResp = Invoke-WebRequest -UseBasicParsing -Uri ($authUrl + '?' + $authorizeQuery) -WebSession $session
$loginUri = $loginResp.BaseResponse.ResponseUri.AbsoluteUri
Write-Host "    redirected to: $loginUri"
if ($loginUri -notlike '*login*') { throw 'Expected to be redirected to /login first' }

Write-Host "==> Logging in as $Username"
$targetMatch = [regex]::Match($loginUri, '[?&]target=([^&]+)')
if (-not $targetMatch.Success) { throw 'login URL did not contain target' }
$target = [uri]::UnescapeDataString($targetMatch.Groups[1].Value)
$post = Invoke-WebRequest -UseBasicParsing -Uri $loginUrl -Method Post -WebSession $session -Body @{ target = $target; username = $Username; password = $Password } -ContentType 'application/x-www-form-urlencoded'
$consentUri = $post.BaseResponse.ResponseUri.AbsoluteUri
Write-Host "    redirected to: $consentUri"
if ($consentUri -notlike '*consent*') { throw 'Expected to reach /consent after login' }

Write-Host "==> Approving consent"
$sep = if ($consentUri.Contains('?')) { '&' } else { '?' }
$approveUri = $consentUri + $sep + 'action=approve'
$finalUri = $null
try {
    $approve = Invoke-WebRequest -UseBasicParsing -Uri $approveUri -WebSession $session
    $finalUri = $approve.BaseResponse.ResponseUri.AbsoluteUri
} catch {
    # redirect_uri points to /callback on the same server; after redirect it returns 404.
    # The authorization code is present in the final redirect URI.
    if ($_.Exception.Response) {
        $finalUri = $_.Exception.Response.ResponseUri.AbsoluteUri
    } else {
        throw
    }
}
Write-Host "    final redirect: $finalUri"
if ($finalUri -notlike '*code=*') { throw 'No authorization code was returned in the redirect URI' }

$code = [uri]::UnescapeDataString([regex]::Match($finalUri, '[?&]code=([^&]+)').Groups[1].Value)
Write-Host "    authorization code=$code"

Write-Host "==> Exchanging code for access token"
$tokenBody = @{
    grant_type    = 'authorization_code'
    code          = $code
    redirect_uri  = $redirectUri
    code_verifier = $codeVerifier
    client_id     = $ClientId
    client_secret = $ClientSecret
}
$token = Invoke-RestMethod -Uri $tokenUrl -Method Post -Body $tokenBody -ContentType 'application/x-www-form-urlencoded'
$accessToken = $token.access_token
$preview = $accessToken
if ($preview.Length -gt 16) { $preview = $preview.Substring(0,16) + '...' }
Write-Host "    access_token=$preview"
Write-Host "    token_type=$($token.token_type) scope=$($token.scope) expires_in=$($token.expires_in)"

Write-Host "==> Calling MCP initialize with Bearer token"
$headers = @{
    'Accept'        = 'application/json, text/event-stream'
    'Content-Type'  = 'application/json'
    'Authorization' = "Bearer $accessToken"
}
$initBody = @{ jsonrpc = '2.0'; id = 1; method = 'initialize'; params = @{ protocolVersion = '2025-03-26'; capabilities = @{}; clientInfo = @{ name = 'oauth-demo.ps1'; version = '1.0' } } } | ConvertTo-Json -Depth 8
$init = Invoke-WebRequest -UseBasicParsing -Uri $mcpUrl -Method Post -Headers $headers -Body $initBody
$sessionId = [string]$init.Headers['Mcp-Session-Id']
Write-Host "    status=$($init.StatusCode) Mcp-Session-Id=$sessionId"
Write-Host "    response headers:"
$init.Headers.GetEnumerator() | ForEach-Object { Write-Host "      $($_.Key)=$($_.Value)" }
Write-Host $init.Content

$headers['Mcp-Session-Id'] = $sessionId
Write-Host "    request headers for tools/list:"
$headers.GetEnumerator() | ForEach-Object { Write-Host "      $($_.Key)=$($_.Value)" }
Write-Host "==> Calling tools/list"
$listBody = @{ jsonrpc = '2.0'; id = 2; method = 'tools/list'; params = @{} } | ConvertTo-Json -Depth 6
$list = Invoke-WebRequest -UseBasicParsing -Uri $mcpUrl -Method Post -Headers $headers -Body $listBody
Write-Host $list.Content

Write-Host "==> Calling tools/call echo"
$callBody = @{
    jsonrpc = '2.0'
    id = 3
    method = 'tools/call'
    params = @{ name = 'echo'; arguments = @{ text = 'hello-oAuth' } }
} | ConvertTo-Json -Depth 8
$call = Invoke-WebRequest -UseBasicParsing -Uri $mcpUrl -Method Post -Headers $headers -Body $callBody
Write-Host $call.Content

Write-Host ""
Write-Host "SUCCESS: full OAuth Authorization Code + PKCE flow completed, MCP endpoint called with Bearer token."